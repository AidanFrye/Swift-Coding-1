//
//  ViewController.swift
//  Aidan_Frye_Test1
//
//  Author: Aidan Frye
//  Last Modified: 9/21/23
//

import UIKit

class ViewController: UIViewController {
    //create variables and outlets for program
    @IBOutlet weak var countdownLabel: UILabel!
    var countdown = 3
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


    //organizing code to make it easier to read / work with
    fileprivate func updateCountdown() {
        switch countdown //the switch function will run based on the value of countdown
        {
        case 3: countdown = 2   //if countdown is 3, set it to 2
            view.backgroundColor = .blue     //change color to blue
            countdownLabel.text = "2"       //set the label text to 2
            
        case 2: countdown = 1    //if countdown is 2, set it to 1
            view.backgroundColor = .systemPink  //change color to pink
            countdownLabel.text = "1"       //set the label text to 1
            
        case 1:
            countdown = 0    //if countdown is 1, set it to 0
            view.backgroundColor = .red      //change color to red
            countdownLabel.text = "Blast Off!"  //set the label text to Blast Off!
            
        default: countdown = 3      //if countdown is 0, set it to 3
            view.backgroundColor = .black   //change color to black
            countdownLabel.text = "3"       //set the label text to 3
        }
        
        /*the switch statement covers all possible states of the code, so it loops
         between 4 states everytime you press the button */
    }

    //when button pressed, run updateCountdown
    @IBAction func buttonPressed(_ sender: Any)
    {
        updateCountdown()
    }
}

