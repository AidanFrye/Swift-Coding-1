//
//  ViewController.swift
//  UIKitExample
//
//  Created by lab on 10/19/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func buttonPressed(_ sender: UIButton)
    {
        print("Button Pressed!")
    }
    
    
    @IBAction func switchToggle(_ sender: UISwitch) //only a switch can check if sender.isOn, so set the sender to UISwitch for code to work
    {
        if(sender.isOn) //code will only trigger if switch is let go of, and the value has swapped from on to off or vice versa
        {
            print("Switch on!")
        }
        else
        {
            print("Switch off!")
        }
    }
    
    @IBAction func sliderChanged(_ sender: UISlider) //changes the value of the slider to an int and prints it when its changes, even by .0001, so you end up getting the same number printed a bunhc of times in a row because of integer rounding
    {
    let Value: Int = Int(sender.value)
        print(Value)
    }
    
    
    @IBAction func textField(_ sender: UITextField) //triggered by the return key
    {//make sure you set the trigger to primary action triggered
        if let text = sender.text //this formatting used so app doesnt implode
        {
            print(text)
        }
    }
    
    
    @IBAction func tapLocation(_ sender: UITapGestureRecognizer) //when added, this isnt a visible ui object in the view, you have to drag over from the side bar
    {
        let location = sender.location(in: view)
        print(location)
    }
}

