//
//  MathQuizViewController.swift
//  FinalProjectCalculatorApp
//
//  Created by lab on 12/8/23.
//

import UIKit

var correctQuestions = 0
var totalQuestions = 0

class MathQuizViewController: UIViewController {
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerTextField: UITextField!
    @IBOutlet weak var checkMeMessage: UILabel!
    
    var currentOperation = ""
    var num1 = 0
    var num2 = 0
    var answer = 150 //impossible answer to start to enable safeguards

    override func viewDidLoad() {
        super.viewDidLoad()
        correctQuestions = 0 //reset the quiz so the user can take it again
        totalQuestions = 0
    }
    
    @IBAction func operationSelected(_ sender: UIButton) //runs every time a math question is selected
    {
        currentOperation = sender.configuration!.title! //set the math operation type to the button selected
        questionLabel.text = "\(currentOperation)"
        askQuestion()
    }
    
    func askQuestion() //asks a random math question of the correct type
    {
        num1 = Int.random(in: 0...12)
        num2 = Int.random(in: 0...12)
        switch currentOperation {
        case "Add":
            questionLabel.text = "What is \(num1) + \(num2)?"
            answer = num1 + num2
        case "Subtract":
            while(num2 > num1)
            {
                num1 = Int.random(in: 0...12)
                num2 = Int.random(in: 0...12)
            }
            questionLabel.text = "What is \(num1) - \(num2)?"
            answer = num1 - num2
        case "Multiply":
            questionLabel.text = "What is \(num1) * \(num2)?"
            answer = num1 * num2
        default: break
        }
    }
    
    @IBAction func checkMeAction()  //runs the code to check the problem
    {
        if(answerTextField.text == String(answer)) //if the answer is correct
        {
            correctQuestions += 1
            checkMeMessage.text = "Good Job!"
            totalQuestions += 1
            askQuestion()
            answerTextField.text = ""
        }
        else if(answer == 150) //if the user hasn't selected a problem type, this code will run
        {
            checkMeMessage.text = "Select a math problem to start!"
        }
        else //if the answer is wrong
        {
            checkMeMessage.text = "Oops! Try again!"
            totalQuestions += 1
            askQuestion()
            answerTextField.text = ""
        }
    }
}
