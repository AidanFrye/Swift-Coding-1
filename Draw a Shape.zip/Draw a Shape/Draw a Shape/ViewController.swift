//
//  ViewController.swift
//  Draw a Shape
//
//  Created by Paige Meeker on 10/16/23.
//

import UIKit

class ViewController: UIViewController {

    var shape: String = ""
    var max: Int = 6
    var diamondMax = 12
    
    @IBOutlet weak var squareButton: UIButton!
    @IBOutlet weak var tri1Button: UIButton!
    
    @IBOutlet weak var tri2Button: UIButton!
    
    @IBOutlet weak var surpriseButton: UIButton!
    @IBOutlet weak var tri3Button: UIButton!
    
    @IBOutlet weak var treeButton: UIButton!
    @IBOutlet weak var tri4Button: UIButton!
    @IBOutlet weak var shapeDisplay: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        squareButton.setTitle("Square", for: .normal)
        tri1Button.setTitle("Triangle1", for: .normal)
        tri2Button.setTitle("Triangle2", for: .normal)
        tri3Button.setTitle("Triangle3", for: .normal)
        tri4Button.setTitle("Triangle4", for: .normal)
        treeButton.setTitle("Tree", for: .normal)
        surpriseButton.setTitle("Surprise", for: .normal)
    }

    func square() { //given
        /*
         Code example:  How to draw a square with
         nested loops!
         */
        for _ in 1...max {
            for _ in 1...max {
                shape += "*"
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }
    
    func tri1() {
        for i in 1...max {
            // create spaces before * for triangle
            let spaces = max - i
            var j = 1
            // add in the *'s needed for each line
            for _ in 1...i {
                shape += "*"
            }
            while j <= spaces {
                shape += " "
                j += 1
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }

    func tri2() { //given
        for i in 1...max {
            // create spaces before * for triangle
            let spaces = max - i
            var j = 1
            while j <= spaces {
                shape += " "
                j += 1
            }
            // add in the *'s needed for each line
            for _ in 1...i {
                shape += "*"
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }
    
    func tri3() {
        for i in 1...max {
            // create spaces before * for triangle
            let spaces = max - i
            var j = 1
            // add in the *'s needed for each line
            for _ in i...6 {
                    shape += "*"
            }
            while j >= spaces {
                shape += " "
                j -= 1
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }
    
    func tri4() {
        for i in 1...max {
            // create spaces before * for triangle
            let spaces = max - i
            var j = 4
            // add in the *'s needed for each line
            while j >= spaces {
                shape += " "
                j -= 1
            }
            for _ in i...6 {
                    shape += "*"
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }
    
    func tree() {
        for i in 1...max {
            // create spaces before * for triangle
            let spaces = max - i
            var j = 1
            while j <= spaces {
                shape += " "
                j += 1
            }
            // add in the *'s needed for each line
            for _ in 1...i {
                shape += "*"
            }
            for k in 0...i {
                if(k > 1){
                    shape += "*"
                }
            }
            shape += "\n"
        }
        shapeDisplay.text = shape
    }
    
    func surprise() { //so close to making a diamond
        for i in 1...diamondMax {
            if(i < 7){
                // create spaces before * for triangle
                let spaces = max - i
                var j = 1
                while j <= spaces {
                    shape += " "
                    j += 1
                }
                // add in the *'s needed for each line
                for _ in 1...i {
                    shape += "*"
                }
                for k in 0...i {
                    if(k > 1){
                        shape += "*"
                    }
                }
                shape += "\n"
            }
            if(i > 7){
                // create spaces before * for triangle
                let spaces = max - i
                var j = -2
                while j >= spaces {
                    shape += " "
                    j -= 1
                }
                // add in the *'s needed for each line
                for _ in i...12 {
                    shape += "*"
                }
                for k in i...12 {
                    if(k > 1){
                        if(i < 12){
                            shape += "*"
                        }
                    }
                }
                shape += "\n"
            }
            shapeDisplay.text = shape
        }
    }
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        shape = ""
        let buttonType = sender.currentTitle!
        switch buttonType {
        case "Square": square()
        case "Triangle1": tri1()
        case "Triangle2": tri2()
        case "Triangle3": tri3()
        case "Triangle4": tri4()
        case "Tree": tree()
        default: surprise()
        }
        
    }
    
}

