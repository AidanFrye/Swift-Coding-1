//
//  ViewController.swift
//  AutoLayoutPractice
//
//  Created by Aidan Frye on 10/25/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // The only thing that I was wondering about is when I rotated the device in the simulator, the top green label disappeared like its supposed to. When I rotate it back to the original rotation, the green label is off to the left of the view and not on top of the red label
}

