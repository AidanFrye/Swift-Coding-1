import UIKit

struct Student
{
    var firstName:String
    var lastName:String
    var fullName:String
    {
        firstName + " " + lastName
    }
    var age:Int 
    var gpa:Double
    //define structure variables
    
    
    func description() -> String
    {
        return "Hello, my name is \(fullName). I'm \(age) years old and have a gpa of \(gpa)."
    }
    //provide templating for description function
    
    mutating func nickname(nickname: String) {
        firstName = nickname
    }
    //allow for changing structure data in runtime
}

var student1 = Student(firstName: "John", lastName: "Smith", age: 20, gpa: 3.85)
//create student1 as an instance

var student2 = student1 //created a second student instance with the exact same configuration as student1, john

print(student1) //print with no formatting

print(student1.description()) //print with formatting

student1.nickname(nickname:"Shorty")//change firstName to a nickname

print(student1.description())//print with nickname



struct Temperature //create temperature structure
{
    var celcius:Double //add celcius as a variable in the structure
    var farenheit:Double
    {
        celcius * 1.8 + 32//compute farenheit based off celcius
    }
    var kelvin:Double
    {
        celcius + 273.15//compute kelvin based of celcius
    }
    
    static var boilingPoint = 100 //create a variable that never changes across temperature instances
    
    func currentTemps() -> String
    {
        return "The current temperature is: \n \(celcius) Celcius \n \(farenheit) Farenheit \n \(kelvin) Kelvin"
    } //make templating for printing current temperatures
}

var currentTemp = Temperature(celcius: 25.5) //because farenehit and kelvin are calculated based off celcius, we dont need them here in creation of an object
//create current temperature instance

print(currentTemp.currentTemps()) //print current temperature in format
