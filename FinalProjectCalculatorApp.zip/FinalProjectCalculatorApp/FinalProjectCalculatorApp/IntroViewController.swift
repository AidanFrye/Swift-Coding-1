//
//  ViewController.swift
//  FinalProjectCalculatorApp
//
//  Created by Aidan Frye on 12/8/23.
//
//  My plan for creating this app is to make three view controllers which each of the
//  individual components required on them. The first one is relatively easy, the bulk of
//  the logic will be on the second controller. I plan to make a stack view to hold the labels and inputs,
//  and I will use a switch statement plus 3 buttons, one for each operation, to determine what question to ask
//  I will use a variable to keep track of the questions answered correctly and total
//  questions, and pass those variables to the results screen on the third view
//  I used past projects like the personality quiz, and apple pie for reference, and the textbook as my resources. 

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

