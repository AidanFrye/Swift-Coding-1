//
//  ViewController.swift
//  randomBackgrounds
//
//  Created by lab on 9/19/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var labelOutlet: UILabel!
    
        //make variable for background color
    var randomBackgroundColor: Int = 0
    
        //make a function to update background color
    fileprivate func updateBackgroundColor()
    {
            //make a random int and update the label
        randomBackgroundColor = Int.random(in: 1...5)
        labelOutlet.text = String(randomBackgroundColor)
            //change the background color based on the random int
        switch randomBackgroundColor
        {
        case 1: view.backgroundColor = .blue
        case 2: view.backgroundColor = .red
        case 3: view.backgroundColor = .green
        case 4: view.backgroundColor = .yellow
        default: view.backgroundColor = .purple
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
            // Do any additional setup after loading the view.
            //update background so the program starts live, and not as a white screen
        updateBackgroundColor()
    }
    
        //when button pressed, update background color
    @IBAction func buttonPressed(_ sender: Any)
    {
        updateBackgroundColor()
    }
}
