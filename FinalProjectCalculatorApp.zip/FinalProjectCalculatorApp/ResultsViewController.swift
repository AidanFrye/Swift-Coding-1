//
//  ResultsViewController.swift
//  FinalProjectCalculatorApp
//
//  Created by lab on 12/8/23.
//

import UIKit

class ResultsViewController: UIViewController {

    @IBOutlet weak var responseLabel: UILabel!
    @IBOutlet weak var correctLabel: UILabel!
    @IBOutlet weak var missedLabel: UILabel!
    @IBOutlet weak var whatLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let missedQuestions = totalQuestions - correctQuestions
        missedLabel.isHidden = false
        correctLabel.isHidden = false
        whatLabel.isHidden = true
        
        if(totalQuestions == 0) //triggers if they never answered a question
        {
            view.backgroundColor = .green
            responseLabel.text = "What?"
            missedLabel.isHidden = true
            correctLabel.isHidden = true
            whatLabel.isHidden = false
            whatLabel.text = "You didn't answer a question!"
        }
        else if (totalQuestions == correctQuestions)
        {
            view.backgroundColor = .yellow
            responseLabel.text = "Great Job!"
        }
        else if (correctQuestions > missedQuestions)
        {
            view.backgroundColor = .purple
            responseLabel.text = "Almost There!"
        }
        else if (missedQuestions > correctQuestions)
        {
            view.backgroundColor = .blue
            responseLabel.text = "Keep Practicing!"
        }
        correctLabel.text = "Correct answers: \(correctQuestions)"
        missedLabel.text = "Incorrect answers: \(missedQuestions)"
        // Do any additional setup after loading the view.
    }
    
    
}
