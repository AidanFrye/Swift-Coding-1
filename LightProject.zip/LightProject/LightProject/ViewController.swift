//
//  ViewController.swift
//  LightProject
//
//  Created by Aidan Frye on 9/14/23.
//  Last modified: 9/14/23

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateUI()
    }
    
var lightOn = true
    
    //to make functions, highlight code you want to make a function, go to editor in the top bar of the computer,
    //select refractor, and click extract to method, you can also make them manually by using func(){}
    
    fileprivate func updateUI()
    {
        //ternary operator replaces an if true statement
        //if lightOn == true then .white; else, .black
        view.backgroundColor = lightOn ? .cyan : .darkGray
    }
    
    @IBAction func buttonPressed(_ sender: Any)
    {
        lightOn.toggle()
        updateUI()
    }
}
