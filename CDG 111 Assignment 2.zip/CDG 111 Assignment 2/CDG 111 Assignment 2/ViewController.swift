//
//  ViewController.swift
//  CDG 111 Assignment 2
//
//  Created by lab on 9/13/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    var pressed = true;

    @IBOutlet weak var AUCodingLabel: UILabel!
    
    @IBOutlet weak var lookAtMeLabel: UILabel!
    
    @IBOutlet weak var canICodeOutlet: UIButton!
    
    @IBAction func canICodeButton(_ sender: Any)
    {
        pressed.toggle()
        lookAtMeLabel.isHidden.toggle()
        if(pressed == false){
            AUCodingLabel.text = "AU Coding Rocks"
            canICodeOutlet.setTitle("Yes, I can!", for: .normal)
        }
        else
        {
            AUCodingLabel.text = "AU Coding"
            canICodeOutlet.setTitle("Can I code?", for: .normal)
        }
    }
    
}

/*finding a way to make hidden text appear was fun. I kept looking at why
 the button got a lot smaller once pressed, and I couldn't figure it out. I saw
 it happening in the hint videos I looked at on canva as well. */
