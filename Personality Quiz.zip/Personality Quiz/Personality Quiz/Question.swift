//
//  Question.swift
//  Personality Quiz
//
//  Created by lab on 12/4/23.
//

import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

enum ResponseType {
    case single, multiple, range
}

struct Answer {
    var text: String
    var type: AnimalType
}

enum AnimalType: Character {
    case fish = "🐠", bird = "🕊️", horse = "🐎", penguin = "🐧"
    
    var definition: String {
        switch self {
        case .fish:
            return "You are very social. You enjoy big gatherings and are probably extroverted."
        case .bird:
            return "You are a very unique person, and don't care much about what others think about you."
        case .horse:
            return "You are very calm, and not much gets you excited or stressed. You go with the flow on most things."
        case .penguin:
            return "You are very naturally curious, and are well liked by most everyone you meet."
        }
    }
}
