//
//  ViewController.swift
//  Personality Quiz
//
//  Created by lab on 11/28/23.
//

import UIKit


class ViewController: UIViewController
{
    
    @IBAction func unwindToQuizIntroduction(segue: UIStoryboardSegue)
    {
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

