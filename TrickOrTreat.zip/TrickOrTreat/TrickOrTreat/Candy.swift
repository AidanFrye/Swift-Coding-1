//
//  Candy.swift
//  TrickOrTreat
//
//  Created by lab on 10/9/23.
//

import Foundation

//create the Candy structure
struct Candy {
    //create the three properties of the candy
    var Name: String
    var Amount: String //used a string instead of an int, because if an int is used, any time the user inputs letters instead of only numbers, the app crashes, (like two vs. 2)
    var Size: String
    
    /* I chose these three properties because they all have easy and distinct answers. I debated adding flavor, but different people may describe the flavor in different ways.
       The name of the candy, the amount you have, and the size (eg. small/medium/large/family), are easy distinct answers, and given the same candy, every user should input the same things.
     */
    
    //create the function to print the description of the candy
    func candyDescription() -> String {
        return "You have \(Amount) \(Size) sized \(Name)."
    }
    
}
