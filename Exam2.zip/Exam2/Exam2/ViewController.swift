//
//  ViewController.swift
//  Exam2
//
//  Created by lab on 11/9/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var colorLabel: UILabel!
    
    @IBOutlet var colorButtons: [UIButton]!
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        var colorPressed = sender.configuration!.title!
        colorLabel.text = colorPressed
        switch colorPressed {
        case "Blue": view.backgroundColor = .blue
        case "Brown": view.backgroundColor = .brown
        case "Red": view.backgroundColor = .red
        case "Magenta": view.backgroundColor = .magenta
        case "Black": view.backgroundColor = .black
        case "Gray": view.backgroundColor = .gray
        default: view.backgroundColor = .purple
        }
    }
}

