import UIKit

/*
 For this first assignment, follow the instructions in the comments, typing below each comment the requested code. 
 */

/*
 1. Add a comment that includes your name, last modified date, CDG 111 Assignment 1, and any additional information you'd like me to have.
 */

//Aidan Frye, Last Modified: 9/13, CDG 111 Assignment 1

/*
 2. Create either a constant or a variable that will contain a String (which should you use for this?). It should store your first name. Use Type Inference to give your constant or variable a value.
 */

let firstName = "Aidan"

/*
 3. Create either a constant or a variable that will contain a String (which should you use for this?). It should store your last name. Use Type Annotation. Then, use assignment to give your constant or variable a value.
 */

let lastName: String
//print(lastName)
lastName = "Frye"

/*
 4. Between the declaration and the assignment of your constant/variable above, add a print statement to print the constant/variable. Does your code compile, or is there an error? Why? Add a comment to explain what happened and why you believe it happened. Then, use a single line comment to comment out the print statement.
 */

//The code gave an error because I was calling for a variable with an empty value. When it is commented out and placed below the assignment, the code works just fine.

/*
 5. Add a print statement that will print the phrase "My name is __  __."  where __ __ is filled in with your constant/variables for first and last name.
 */

print("My name is " + firstName + " " + lastName + ".")

/*
 6. Create four variables called w, x, y, and z. Assign w the value 10, x the value 3, y the value 17.0, and z the value 2.0
 */

var w = 10
var x = 3
var y = 17.0
var z = 2.0


/*
 7. Print the result of w divided by x and w modulus x (the remainder operator). Add a comment to explain the answers that are printed.
 
 Your print statement should not just contain the answer - make it look nice. It should look something like:
 
 "The result of 10 divided by 3 is: ** "
 */

let wDivideByX = w / x
let wModulusX = w % x
print("The result of 10 divided by 3 is: \(wDivideByX) with a remainder of \(wModulusX)." )

/*
 8.Print the result of y divided by z.
 */

let yDivideByZ = y / z

print("The result of 17.0 divided by 2.0 is: \(yDivideByZ).")

/*
 9. Print the result of adding x and y. Can you do it? If so, great! If not, add a comment as to why not and add code to fix the problem. Explain the code you added in the comment.
 */

let xPlusY = Double(x) + y
print("The result of 3 plus 17.0 is: \(xPlusY).")

//I could not add them originally so I had to temporarily convert x to a double to have matching variable types.

/*
 10. Subtract z from y and store the result in y. Use a compound assignment operator.
 */

y -= z

/*
 11. Create a variable to hold a random integer value between 0 and 10. We saw an example in class. The code uses: Int.random(in: 0...10)
 
 */

var randomInt = Int.random(in: 0...10)


/*
 12. Using the variable above, make a decision. If the value is less than 5, print "That's low." Otherwise, print "That's high."
 */

if(randomInt < 5)
{
    print("That's low.")
}
else
{
    print("That's high.")
}

/*
 13. Using the variable above, change the value to a different random number with a range of 10-12.
 */

randomInt = Int.random(in: 10...12)

/*
 14. Using if statements, create code that prints a different statement for each possible value between 10 and 12.
 */

if(randomInt == 10)
{
    print("The value of the number is 10.")
}
else if(randomInt == 11)
{
    print("The value of the number is 11.")
}
else
{
    print("The value of the number is 12.")
}



/*
 15. Create the same code you made in #14 with a switch statement instead.
 */

switch randomInt
{
case 10:
    print("The value of the number is 10.")
case 11:
    print("The value of the number is 11.")
default:
    print("The value of the number is 12.")
}


/*
 16. Create two constants, a and b. Assign a the value 3. Assign b a random value between 1 and 5.
 */

let a = 3
let b = Int.random(in: 1...5)

/*
 17. Print the result of each of the following comparison operators:
 
 less than <
 greater than >
 less than or equal to <=
 greater than or equal to >=
 equal to ==
 */

print("Is a greater than b? \(a < b)")
print("Is a less than b? \(a > b)")
print("Is a greater than or equal to b? \(a <= b)")
print("Is a less than or equal to b? \(a >= b)")
print("Is a equal to b? \(a == b)")


/*
 18. Add a comment about this assignment. Do you feel like you understand how to create and use variables and constants? Mathematical and comparison operators? Make decisions using if and switch?
 
     Add any questions you may have about each topic.
 */

//I think I'm doing good with this assignment!
