//
//  ViewController.swift
//  What Does the Animal Say
//
//  Created by Aidan on 11/2/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var outputLabel: UILabel!
    
    @IBOutlet var buttonCollection: [UIButton]!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func buttonPressed(_ sender: UIButton) { //when any button is pressed
        let animal = sender.configuration!.title! //set variable to button pressed
        switch animal { //do different things based on what button was pressed
        case "Dog":
            outputLabel.text = "The dog says woof!"
        case "Cat":
            outputLabel.text = "The cat says meow!"
        case "Horse":
            outputLabel.text = "The horse says neigh!"
        case "Cow":
            outputLabel.text = "The cow says moo!"
        default:
            outputLabel.text = "The ___ Says"//the reset button triggers the default case
        }
        imageView.image = UIImage(named: animal) //change picture based on button pressed
    }
}

