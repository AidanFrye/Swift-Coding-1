//
//  ViewController.swift
//  TrickOrTreat
//
//  Last modified by Aidan on 10/9/23.
//

import UIKit

class ViewController: UIViewController {

    //create variables and connections with interface objects
    @IBOutlet weak var TextView: UITextView!
    
    @IBOutlet weak var NameTextField: UITextField!
    
    @IBOutlet weak var AmountTextField: UITextField!
    
    @IBOutlet weak var SizeTextField: UITextField!
    
    //create array that holds the candies you input
    var candyList: [Candy] = []
    
    //setup starting view, instructions in the text view on startup
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TextView.text = "Input the name and amount of candy you got below and press the trick or treat button!"
    }

    //this is called when button is pressed
    func updateTextField()
    {
        //create the start of the printed text
        var listOfCandy = "My candy: \n"
        
        //for each candy in the array, add the description of that candy to the printed text
        for eachCandy in candyList {
            listOfCandy += eachCandy.candyDescription() + "\n"
        }
        
        //print the text and reset the text fields for the next input
        TextView.text = listOfCandy
        NameTextField.text = ""
        AmountTextField.text = ""
        SizeTextField.text = ""
    }
    
    //when button is pressed, update the array with the candy currently input and update the method to update the text shown
    @IBAction func trickOrTreatButtonPressed(_ sender: Any) {
        let candy1 = Candy(Name: NameTextField.text!, Amount: AmountTextField.text!, Size: SizeTextField.text!)
        candyList.append(candy1)
        updateTextField()

    }
}

